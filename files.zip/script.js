/* ═══════════════════════════════════════
   DATA
═══════════════════════════════════════ */
const STYLES_DATA = [
  { id: "cinematic",   name: "Cinematic",    icon: "◈", color: "#F59E0B", model: "Runway ML v3" },
  { id: "anime",       name: "Anime",        icon: "◇", color: "#EC4899", model: "Kling v1.5"   },
  { id: "realistic",   name: "Realistic",    icon: "◉", color: "#22D3EE", model: "Pika 2.0"     },
  { id: "luxury",      name: "Luxury Ad",    icon: "◆", color: "#F59E0B", model: "Runway ML v3" },
  { id: "horror",      name: "Horror",       icon: "▲", color: "#EF4444", model: "Luma Dream"   },
  { id: "motivation",  name: "Motivational", icon: "▶", color: "#A855F7", model: "Kling v1.5"   },
];

const DURATION_DATA = [
  { v: "5",  label: "5 Sekunden",  tag: "Schnell"   },
  { v: "10", label: "10 Sekunden", tag: "Standard"  },
  { v: "30", label: "30 Sekunden", tag: "Pro"       },
];

const FORMAT_DATA = [
  { v: "9:16",  label: "TikTok 9:16",   icon: "▐" },
  { v: "16:9",  label: "YouTube 16:9",  icon: "▬" },
  { v: "1:1",   label: "Square 1:1",    icon: "■" },
];

const STATUS_STEPS = [
  { label: "Text analysieren",  detail: "NLP verarbeitet deinen Prompt..."   },
  { label: "Prompt optimieren", detail: "GPT-4 verbessert für beste Qualität..." },
  { label: "Modell auswählen",  detail: "Runway ML v3 ausgewählt..."          },
  { label: "Video generieren",  detail: "KI rendert Frames..."                },
  { label: "Finalisieren",      detail: "Komprimierung und Export..."          },
  { label: "Fertig!",           detail: "Video bereit zum Download"            },
];

const EXAMPLE_PROMPTS = [
  "Ein epischer Löwe läuft durch New York bei Nacht",
  "Motivierendes Gym Video mit Alpha Energie",
  "Luxury Ferrari Werbeclip in Dubai",
  "Anime Kampf Szene im strömenden Regen",
];

/* ═══════════════════════════════════════
   STATE
═══════════════════════════════════════ */
let selectedStyle    = "cinematic";
let selectedDuration = "10";
let selectedFormat   = "16:9";
let generating       = false;
let genDone          = false;
let genInterval      = null;

/* ═══════════════════════════════════════
   PAGE SWITCHING
═══════════════════════════════════════ */
function showDashboard() {
  document.getElementById("landing-page").style.display  = "none";
  document.getElementById("dashboard-page").style.display = "block";
  window.scrollTo(0, 0);
}

function showLanding() {
  document.getElementById("dashboard-page").style.display = "none";
  document.getElementById("landing-page").style.display  = "block";
  window.scrollTo(0, 0);
}

/* ═══════════════════════════════════════
   MOBILE MENU
═══════════════════════════════════════ */
function toggleMobileMenu() {
  const links = document.getElementById("nav-links");
  links.classList.toggle("mobile-open");
}

/* ═══════════════════════════════════════
   TYPEWRITER
═══════════════════════════════════════ */
(function initTypewriter() {
  const el = document.getElementById("typed-text");
  if (!el) return;

  let promptIdx = 0, charIdx = 0, deleting = false;

  function tick() {
    const target = EXAMPLE_PROMPTS[promptIdx % EXAMPLE_PROMPTS.length];

    if (!deleting) {
      charIdx++;
      el.innerHTML = target.slice(0, charIdx) + '<span class="cursor"></span>';
      if (charIdx >= target.length) {
        deleting = true;
        setTimeout(tick, 2200);
        return;
      }
    } else {
      charIdx--;
      el.innerHTML = target.slice(0, charIdx) + '<span class="cursor"></span>';
      if (charIdx === 0) {
        deleting = false;
        promptIdx++;
      }
    }
    setTimeout(tick, deleting ? 35 : 65);
  }

  el.innerHTML = '<span class="cursor"></span>';
  setTimeout(tick, 800);
})();

/* ═══════════════════════════════════════
   FAQ
═══════════════════════════════════════ */
function toggleFaq(btn) {
  const answer = btn.nextElementSibling;
  const plus   = btn.querySelector(".faq-plus");
  const isOpen = answer.classList.contains("open");

  // close all
  document.querySelectorAll(".faq-answer").forEach(a => a.classList.remove("open"));
  document.querySelectorAll(".faq-plus").forEach(p => p.classList.remove("open"));

  if (!isOpen) {
    answer.classList.add("open");
    plus.classList.add("open");
  }
}

/* ═══════════════════════════════════════
   DASHBOARD SECTIONS
═══════════════════════════════════════ */
function switchSection(el, sectionId) {
  // sidebar active state
  document.querySelectorAll(".sidebar-item").forEach(i => i.classList.remove("active"));
  el.classList.add("active");

  // show/hide sections
  document.querySelectorAll(".dash-section").forEach(s => s.style.display = "none");
  document.getElementById("section-" + sectionId).style.display = "block";
}

/* ═══════════════════════════════════════
   BUILD STYLE SELECTOR
═══════════════════════════════════════ */
function buildStyleGrid() {
  const container = document.getElementById("style-grid");
  if (!container) return;

  container.innerHTML = STYLES_DATA.map(s => `
    <div class="style-btn ${s.id === selectedStyle ? "active" : ""}"
         data-style="${s.id}" onclick="selectStyle('${s.id}')">
      <span class="style-btn-icon" style="color:${s.color}">${s.icon}</span>
      <span class="style-btn-name">${s.name}</span>
      ${s.id === selectedStyle ? `<div class="style-btn-bar" style="background:linear-gradient(90deg,${s.color},transparent)"></div>` : ""}
    </div>
  `).join("");
}

function selectStyle(id) {
  selectedStyle = id;
  buildStyleGrid();
  updateModelInfo();
}

/* ═══════════════════════════════════════
   BUILD DURATION LIST
═══════════════════════════════════════ */
function buildDurationList() {
  const container = document.getElementById("duration-list");
  if (!container) return;

  container.innerHTML = DURATION_DATA.map(d => `
    <div class="option-item ${d.v === selectedDuration ? "active" : ""}"
         onclick="selectDuration('${d.v}')">
      <span class="option-label">${d.label}</span>
      <span class="option-tag">${d.tag}</span>
    </div>
  `).join("");
}

function selectDuration(v) {
  selectedDuration = v;
  buildDurationList();
}

/* ═══════════════════════════════════════
   BUILD FORMAT LIST
═══════════════════════════════════════ */
function buildFormatList() {
  const container = document.getElementById("format-list");
  if (!container) return;

  container.innerHTML = FORMAT_DATA.map(f => `
    <div class="option-item ${f.v === selectedFormat ? "active" : ""}"
         onclick="selectFormat('${f.v}')">
      <span style="font-size:15px;color:${f.v === selectedFormat ? "#A855F7" : "#8890A8"}">${f.icon}</span>
      <span class="option-label">${f.label}</span>
    </div>
  `).join("");

  // update preview aspect ratio
  const box = document.getElementById("preview-box");
  if (box) {
    const ratio = selectedFormat === "9:16" ? "9/16" : selectedFormat === "1:1" ? "1/1" : "16/9";
    box.style.aspectRatio = ratio;
  }
}

function selectFormat(v) {
  selectedFormat = v;
  buildFormatList();
}

/* ═══════════════════════════════════════
   PROMPT CHIPS
═══════════════════════════════════════ */
function buildPromptChips() {
  const container = document.getElementById("prompt-chips");
  if (!container) return;

  container.innerHTML = EXAMPLE_PROMPTS.map(ex => `
    <button class="prompt-chip" onclick="setPrompt(this, \`${ex}\`)">${ex.slice(0, 28)}…</button>
  `).join("");
}

function setPrompt(btn, text) {
  const input = document.getElementById("prompt-input");
  if (input) {
    input.value = text;
    checkPrompt();
  }
}

/* ═══════════════════════════════════════
   GENERATE BUTTON ENABLE/DISABLE
═══════════════════════════════════════ */
function checkPrompt() {
  const input = document.getElementById("prompt-input");
  const btn   = document.getElementById("gen-btn");
  if (!input || !btn) return;
  btn.disabled = input.value.trim() === "" || generating;
}

/* ═══════════════════════════════════════
   MODEL INFO
═══════════════════════════════════════ */
function updateModelInfo() {
  const el    = document.getElementById("model-info-text");
  const style = STYLES_DATA.find(s => s.id === selectedStyle);
  if (el && style) {
    el.innerHTML = `Stil <strong style="color:#EEEEF5">${style.name}</strong> → <strong style="color:#EEEEF5">${style.model}</strong> ausgewählt<br>Prompt wird via GPT-4 automatisch optimiert`;
  }
}

/* ═══════════════════════════════════════
   STEP LIST RENDER
═══════════════════════════════════════ */
function renderStepList(currentStep) {
  const container = document.getElementById("step-list");
  if (!container) return;

  container.innerHTML = STATUS_STEPS.map((s, i) => {
    const done    = i < currentStep;
    const active  = i === currentStep;
    const color   = done ? "#22D3EE" : active ? "#EEEEF5" : "#555A6E";
    const opacity = i > currentStep + 1 ? 0.4 : 1;
    const bgColor = done ? "rgba(34,211,238,0.2)" : active ? "rgba(168,85,247,0.2)" : "rgba(255,255,255,0.04)";
    const borderC = done ? "rgba(34,211,238,0.4)" : active ? "rgba(168,85,247,0.4)" : "rgba(255,255,255,0.08)";
    const innerC  = done ? "#22D3EE" : "#A855F7";
    const inner   = done ? "✓" : active ? "●" : "";

    return `<div style="display:flex;align-items:center;gap:10px;font-size:12px;color:${color};opacity:${opacity}">
      <div style="width:18px;height:18px;border-radius:50%;flex-shrink:0;background:${bgColor};border:1px solid ${borderC};display:flex;align-items:center;justify-content:center;font-size:9px;color:${innerC}">${inner}</div>
      ${s.label}
    </div>`;
  }).join("");
}

/* ═══════════════════════════════════════
   GENERATE HANDLER
═══════════════════════════════════════ */
function handleGenerate() {
  const input = document.getElementById("prompt-input");
  if (!input || input.value.trim() === "" || generating) return;

  generating = true;
  genDone    = false;

  const btn = document.getElementById("gen-btn");
  if (btn) {
    btn.disabled  = true;
    btn.innerHTML = '<span class="spinner" style="width:18px;height:18px;margin-right:10px;vertical-align:middle;border-width:2px"></span>Generiere Video...';
  }

  // Show progress card, hide recent/download
  document.getElementById("progress-card").style.display = "block";
  document.getElementById("download-area").style.display  = "none";
  document.getElementById("recent-videos").style.display  = "none";

  // Switch preview to generating state
  document.getElementById("preview-idle").style.display       = "none";
  document.getElementById("preview-done").style.display       = "none";
  document.getElementById("preview-generating").style.display = "block";
  document.getElementById("shimmer").style.display            = "block";

  let step = 0;

  genInterval = setInterval(() => {
    step++;
    const pct = Math.min((step / STATUS_STEPS.length) * 100, 100);

    // Progress bar
    document.getElementById("progress-bar").style.width = pct + "%";
    document.getElementById("progress-pct").textContent  = Math.round(pct) + "%";

    // Step info in preview
    const s = STATUS_STEPS[Math.min(step, STATUS_STEPS.length - 1)];
    document.getElementById("preview-step-label").textContent  = s.label;
    document.getElementById("preview-step-detail").textContent = s.detail;

    // Step list
    renderStepList(step);

    if (step >= STATUS_STEPS.length) {
      clearInterval(genInterval);
      setTimeout(finishGeneration, 700);
    }
  }, 1400);
}

function finishGeneration() {
  generating = false;
  genDone    = true;

  // Preview → done
  document.getElementById("preview-generating").style.display = "none";
  document.getElementById("shimmer").style.display            = "none";
  document.getElementById("preview-done").style.display       = "block";

  // Meta info
  const style = STYLES_DATA.find(s => s.id === selectedStyle);
  document.getElementById("preview-done-meta").textContent =
    `${style ? style.name : ""} · ${selectedDuration}s · ${selectedFormat}`;

  // Progress label
  document.getElementById("progress-label").textContent = "Abgeschlossen";

  // Show download, hide recent
  document.getElementById("download-area").style.display = "flex";
  document.getElementById("recent-videos").style.display = "none";

  // Re-enable gen button
  const btn = document.getElementById("gen-btn");
  if (btn) {
    btn.innerHTML = "⚡ Video jetzt generieren";
    btn.disabled  = false;
  }
}

function resetGenerator() {
  generating = false;
  genDone    = false;

  document.getElementById("progress-card").style.display  = "none";
  document.getElementById("download-area").style.display  = "none";
  document.getElementById("recent-videos").style.display  = "block";

  document.getElementById("preview-generating").style.display = "none";
  document.getElementById("preview-done").style.display       = "none";
  document.getElementById("preview-idle").style.display       = "block";
  document.getElementById("shimmer").style.display            = "none";

  document.getElementById("progress-bar").style.width    = "0%";
  document.getElementById("progress-pct").textContent    = "0%";
  document.getElementById("progress-label").textContent  = "Generierung...";

  const btn = document.getElementById("gen-btn");
  if (btn) { btn.innerHTML = "⚡ Video jetzt generieren"; btn.disabled = true; }
}

/* ═══════════════════════════════════════
   INIT
═══════════════════════════════════════ */
document.addEventListener("DOMContentLoaded", function () {
  buildStyleGrid();
  buildDurationList();
  buildFormatList();
  buildPromptChips();
  updateModelInfo();

  const input = document.getElementById("prompt-input");
  if (input) {
    input.addEventListener("input", checkPrompt);
  }

  // smooth scroll for nav links on landing
  document.querySelectorAll(".nav-link").forEach(link => {
    link.style.cursor = "pointer";
  });
});
